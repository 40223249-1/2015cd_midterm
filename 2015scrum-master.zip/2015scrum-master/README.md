# Introduction

March - July 2015

Welcome, this is an ongoing project record for a university course named collaborative product design principles and practices.

Github integration: https://github.com/product-owner/2015scrum

course website: http://cd-cadp.rhcloud.com




