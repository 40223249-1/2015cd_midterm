# 由 scrum_3 組員所寫的考試報告
除了 Brython, 還有一個 pypy.js 可以參考