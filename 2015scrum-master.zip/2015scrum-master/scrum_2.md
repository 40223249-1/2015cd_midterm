# 由 scrum_2 組員所寫的考試報告
目前全球資訊網的繪圖採用 Brython