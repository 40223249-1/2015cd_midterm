from setuptools import setup

setup(name='CP Project 2014',
      version='1.0',
      description='OpenShift App for CP Project',
      author='MDE NFU Taiwan',
      author_email='2014cpcadp@gmail.com',
      url='http://www.python.org/sigs/distutils-sig/',
      install_requires=['CherryPy'],
     )